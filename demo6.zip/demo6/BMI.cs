﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo5
{
    class BMI
    {
        private double height;
        public double weight;
        public double bmi;
        public BMI(double Height,double Weight)
        {
            this.height = Height;
            this.weight = Weight;

        }
        
        
        
    }
}
