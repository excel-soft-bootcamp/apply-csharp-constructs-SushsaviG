﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo5
{
    class Program
    {
        static void Main(string[] args)
        {
           
            

        BMI b = new BMI(5.6,56);
            bmi = weight / height*2;
            if(bmi<18.5)
            {
                Console.WriteLine("underweight");
            }
            if(bmi>=25)
            {
                Console.WriteLine("overweight");
            }

        }
    }
}
